<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if(auth()->user()->can('user-manage'))
        {
            $user = User::where('created_by',Auth::user()->id)->get();

            return view('admin.user.index', compact('user'));
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if(auth()->user()->can('user-create'))
        {
            $roles = Role::all();

            return view('admin.user.create', compact('roles'));
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if(auth()->user()->can('user-create'))
        {


            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required',
                'password' => 'required|same:confirm-password',
                'role' => 'required',
            ]);

            if($validator->fails())
            {
                $errors = $validator->getMessageBag();

                return redirect()->back()->with('error', $errors->first());
            }

            $filename = '';

            $image    = $request->image;
            $filename = time() . $image->getClientOriginalName();
            $image->move(public_path('image'), $filename);

            $user           = new User();
            $user->name     = $request->name;
            $user->email    = $request->email;
            $user->password = Hash::make($request->password);
            $user->image    = $filename;
            $user->created_by = Auth::user()->id;
            $user->save();

            $user->assignRole($request->input('role'));


            return redirect()->back()->with('success', 'Data Submmited To Successfully');
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

        //        $user = User::find($id);
        //
        //        return view('admin.user.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if(auth()->user()->can('user-edit'))
        {
            $edit  = User::find($id);
            $roles = Role::all();

            return view('admin.user.edit', compact('edit', 'roles'));
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if(auth()->user()->can('user-edit'))
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required',
                'role' => 'required',

            ]);
            if($validator->fails())
            {
                $errors = $validator->getMessageBag();

                return redirect()->back()->with('error', $errors->first());
            }

            $user        = User::find($id);
            $user->name  = $request->name;
            $user->email = $request->email;

            if(!empty($request->image))
            {
                $image    = $request->image;
                $filename = time() . $image->getClientOriginalName();
                $image->move(public_path('image'), $filename);

                $user->image = $filename;
            }
            DB::table('model_has_roles')->where('model_id', $id)->delete();
            $user->save();

            $user->assignRole($request->input('role'));


            return redirect()->back()->with('update', 'Data Updated To Successfully');
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if(auth()->user()->can('user-delete'))
        {
            $delete = User::find($id);
            $delete->delete();

            return redirect()->back()->with('delete', 'User Deleted To Successfully');
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }
}
