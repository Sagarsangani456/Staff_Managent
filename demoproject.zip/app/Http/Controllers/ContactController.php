<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use DateTime;
use carbon\Carbon;

class ContactController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        if(auth()->user()->can('contact-manage'))
        {
            $contact = Contact::all();

            return view('admin.contact.index', compact('contact'));
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if(auth()->user()->can('contact-create'))
        {
            return view('admin.contact.create');
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if(auth()->user()->can('contact-create'))
        {


            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required',
                'contact_number' => 'required',
                'subject' => 'required',
                'message' => 'required',
            ]);
            if($validator->fails())
            {
                $errors = $validator->getMessageBag();

                return redirect()->back()->with('error', $errors->first());
            }

            $contact                 = new Contact();
            $contact->name           = $request->name;
            $contact->email          = $request->email;
            $contact->contact_number = $request->contact_number;
            $contact->subject        = $request->subject;
            $contact->message        = $request->message;
            $contact->save();

            return redirect()->back()->with('success', 'Data To Submited Successfully');
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Contact $contact)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Contact $contact)
    {
        if(auth()->user()->can('contact-edit'))
        {
            return view('admin.contact.edit', compact('contact'));
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Contact $contact)
    {
        if(auth()->user()->can('contact-edit'))
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required',
                'contact_number' => 'required',
                'subject' => 'required',
                'message' => 'required',
            ]);
            if($validator->fails())
            {
                $errors = $validator->getMessageBag();

                return redirect()->back()->with('error', $errors->first());
            }

            $contact                 = $contact;
            $contact->name           = $request->name;
            $contact->email          = $request->email;
            $contact->contact_number = $request->contact_number;
            $contact->subject        = $request->subject;
            $contact->message        = $request->message;
            $contact->update();

            return redirect()->back()->with('success', 'Data  Updated To Successfully');
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Contact $contact)
    {
        if(auth()->user()->can('contact-delete'))
        {

            $contact->delete();

            return redirect()->back()->with([
                                                "status" => 0,
                                                'success' => 'Data Deleted To Successfully',
                                            ]);
        }
        else
        {
            return redirect()->back()->with('error', 'Try again later');
        }


    }
}
