<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;


class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        app()['cache']->forget('spatie.permission.cache');

        $arraypermission = [
            'role-manage',
            'role-create',
            'role-edit',
            'role-delete',
            'user-manage',
            'user-create',
            'user-edit',
            'user-delete',
            'contact-manage',
            'contact-create',
            'contact-edit',
            'contact-delete',
            'support-manage',
            'support-create',
            'support-edit',
            'support-delete',
            'support-reply',
            'note-manage',
            'note-create',
            'account-manage',
            'password-manage',
            'general-manage',
            'company-manage',
            'email-manage',
        ];

        foreach($arraypermission as $arraypermission_list)
        {
            $group_name = strtok($arraypermission_list, '-');

            Permission::create([
                                   'group' => $group_name,
                                   'name' => $arraypermission_list,
                               ]);
        }


        $adminrole = Role::create(
            [
                'name' => 'admin',
            ]
        );

        $adminPermissions = [

             'role-manage',
             'role-create',
             'role-edit',
             'role-delete',
             'user-manage',
             'user-create',
             'user-edit',
             'user-delete',
             'contact-manage',
             'contact-create',
             'contact-edit',
             'contact-delete',
             'support-manage',
             'support-create',
             'support-edit',
             'support-delete',
             'support-reply',
             'note-manage',
             'note-create',
             'account-manage',
             'password-manage',
             'general-manage',
             'company-manage',
             'email-manage',
        ];

        foreach($adminPermissions as $adminPermission_list)
        {
            $permission = Permission::findByName($adminPermission_list);
            $adminrole->givePermissionTo($permission);
        }

        $admin = User::create([
                                  'name' => 'admin',
                                  'email' => 'admin@gmail.com',
                                  'password' => Hash::make('12345678'),
                                  'created_by' => 0,
                                  'image'=>'1696401323user.png'
                              ]);
        $admin->assignRole($adminrole);

    }
}


